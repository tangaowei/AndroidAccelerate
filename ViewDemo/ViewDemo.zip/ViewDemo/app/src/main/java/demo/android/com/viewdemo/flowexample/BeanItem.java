package demo.android.com.viewdemo.flowexample;

/**
 * Created by tangaowei on 18/5/9.
 */

public class BeanItem {
    public String content;
}
